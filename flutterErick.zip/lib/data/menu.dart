import 'package:flutter/material.dart';

class Menu {
  late Color color;

  late IconData icon;

  late String title;
}
