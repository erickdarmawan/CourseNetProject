import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:my_fluttercourse_p2/DataCovid.dart';
import 'package:my_fluttercourse_p2/Movies.dart';
import 'package:my_fluttercourse_p2/catboy2nd.dart';
import 'package:my_fluttercourse_p2/home.dart';
import 'package:my_fluttercourse_p2/login.dart';
import 'home.dart';
import 'register.dart';
import 'dynamic_list_view.dart';
import 'map.dart';
import 'DataCovid.dart';
import 'CovidUpdate.dart';
import 'list_universty.dart';
import 'catboys3.dart';
import 'Page_detail.dart';
import 'search.dart';
import 'result.dart';
import 'listBooking.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'calendarView.dart';
import 'Holiday.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  //await Firebase.initializeApp();
  runApp(MaterialApp(
    routes: {
      'page_home': (context) => HomeWidget(),
      'page_register': (context) => RegisterWidget(),
      'page_login': (context) => LoginWidget(),
      'page_dynamic_view': (context) => DynamicListView(),
      'page_map': (context) => MapWidget(),
      'page_covid': (context) => CovidWidget(),
      'page_covid_update': (context) => CovidUpdateWidget(),
      'page_university': (context) => ListUniversityWidget(),
      'page_catboys': (context) => CatboysWidget(),
      'page_movies': (context) => MovieWidget(),
      'page_detail': (context) => PageDetailWidget(),
      'page_result': (context) => ResultWidget(),
      'page_holiday': (context) => HolidaysWidget(),
    },
    home: LoginWidget(),
  ));
}

class FlutterDemo extends StatelessWidget {
  const FlutterDemo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
      ),
      home: const FlutterHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class FlutterHomePage extends StatefulWidget {
  final String title;

  const FlutterHomePage({Key? key, required this.title}) : super(key: key);

  @override
  State<FlutterHomePage> createState() => _FlutterHomePageState();
}

class FlutterWidget extends StatelessWidget {
  const FlutterWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(
        title: Text("Flutter AppBar"),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        leading: Icon(Icons.menu),
        titleSpacing: 5,
      ),
      body:
          // Row
          Column(
        children: [
          Text('Hello Flutter',
              style: TextStyle(
                color: Colors.brown,
                fontSize: 17,
                fontWeight: FontWeight.w700,
                fontStyle: FontStyle.italic,
              )),
          Text(
            'Welcome Flutter',
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.black,
                fontSize: 17,
                fontWeight: FontWeight.w900,
                fontStyle: FontStyle.normal),
          ),
          Text(
            'Copyright 2022',
            textAlign: TextAlign.left,
            style: TextStyle(
                color: Colors.red,
                fontSize: 17,
                fontWeight: FontWeight.w900,
                fontStyle: FontStyle.normal),
          ),
          Center(
            child: Padding(
              //padding: const EdgeInsets.all(8.0),
              padding: const EdgeInsets.fromLTRB(5, 5, 1, 5),
              //padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 8),
              //padding: EdgeInsets.only(top: 5, bottom: 8),
              child: ElevatedButton(
                  onPressed: () {},
                  child: Text('Submit 1'),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.red),
                  )),
            ),
          ),
          Padding(
            //padding: const EdgeInsets.all(8.0),
            //padding: const EdgeInsets.fromLTRB(5, 5, 1, 5),
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 8),
            //padding: EdgeInsets.only(top: 5, bottom: 8),
            child: OutlinedButton(
                style: ButtonStyle(
                    side: MaterialStateProperty.all(BorderSide(width: 2))),
                onPressed: () {},
                child: Text('Submit 2')),
          ),
          Padding(
            //padding: const EdgeInsets.all(8.0),
            //padding: const EdgeInsets.fromLTRB(5, 5, 1, 5),
            //padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 8),
            padding: EdgeInsets.only(top: 5, bottom: 8),
            child: TextButton(
              onPressed: () {},
              child: Text('Submit 3'),
            ),
          ),
          Padding(
            // padding: const EdgeInsets.all(2.0),
            //padding: const EdgeInsets.fromLTRB(5, 5, 1, 5),
            //padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 8),
            padding: EdgeInsets.only(top: 5, bottom: 8),
            child: IconButton(onPressed: () {}, icon: Icon(Icons.check)),
          ),
          // Align(
          //   alignment: Alignment.centerRight,
          //   child: Text('Hello Boys'),
          // ),
          Divider(
            color: Colors.red,
            height: 80,
            thickness: 3,
          ),
          TextFormField(),
          Image.asset(
            'images/pngfind.com-galaga-png-2648894.png',
            width: 200,
            height: 200,
            color: Colors.blue,
          ),
          // Image.network(
          //   'https://img2.pngdownload.id/20180816/qpz/kisspng-mcdonald-s-museum-logo-portable-network-graphics-c-pronk-geschenken-en-kerstpakketten-referenties-5b7520f8bbf0a6.0511301815344028087698.jpg',
          //   height: 210,
          //   width: 210,
          //),
        ],
      ),
    ));
  }
}

class _FlutterHomePageState extends State<FlutterHomePage> {
  int _counter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'You Pressed:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), //
    );
  }

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }
}
