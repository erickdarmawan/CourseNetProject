//import 'package:calendar_view/calendar_view.dart';
import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';

void main() {
  runApp(const CalendarViewWidget());
}

class CalendarViewWidget extends StatelessWidget {
  const CalendarViewWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
    );
  }
}
